const createMainBot = require('./index.js');
const createKickBot = require('./ticketBot.js');
const mongoose = require("mongoose");
const token = require ('./models/tokens.js')

async function start() {
  try {
    await mongoose.connect("mongodb+srv://Ahmed:12345@ahmed.f1uxuex.mongodb.net/data", {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      useFindAndModify: false,
      useCreateIndex: true
    });

    console.log('Connected to MongoDB');

    const index = await createMainBot();

    const tokenDocs = await token.find();
    const tokens = tokenDocs.reduce((acc, cur) => {
      if (cur.botType === 'ticket') {
        acc.kick = cur.botToken;
      } else if (cur.botType === 'ban') {
        acc.ban = cur.botToken;
      }
      return acc;
    }, {});

    const ticketBot = createticketBot(tokens.kick);
    const banBot = createBanBot(tokens.ban);

    if (ticketBot) {
      console.log(`Kick bot is online with token ${tokens.kick}`);
    }
    if (banBot) {
      console.log(`Ban bot is online with token ${tokens.ban}`);
    }
  } catch (error) {
    console.error(error);
  }
}

start();
