
const config = require("./config.json");
const prefix = config.prefix;
const Discord = require("discord.js");
const fs = require('fs');
const { MessageAttachment } = require('discord.js');
const { MessageEmbed , permissionOverwrites , MessageSelectMenu , ChannelType , MessageButton, MessageActionRow ,  Permissions} = require("discord.js");
const { Client, Intents } = require('discord.js');
const client = new Discord.Client({
  intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS"]
});



// Require the ban bot module and pass the Client class
// const banBot = require('./banBot')(Client, '');

client.on('ready', () => {
  console.log('Bot is online!');
});
const mongoose = require("mongoose");
const db = require("./models/shop");
const user_db = require("./models/user");
const toto = require("./models/steck");
const tokens = require("./models/tokens");
const setSlash = require("./slash");
const axios = require("axios");
const i18n = require('i18n');
    
i18n.configure({
  locales: ['en', 'ar'],
  directory: __dirname + '/locales',
  defaultLocale: 'en',
  objectNotation: true
});

mongoose.connect(" mongodb+srv://behoo:12345Wageh@tuortl.ih3qjnq.mongodb.net/data");

client.on("ready", async () => {
  console.log(client.user.tag);
  await setSlash(client);
});

process.on("unhandledRejection", error => {
  return;
});
process.on("unhandledRejection", error => {
  return;
});
process.on("unhandledRejection", error => {
  return;
});

process.on("unhandledRejection", error => {
  return console.log(error)
});




client.on('ready', () => {
  function abady() {
    let status = [`Ahmed Sn Channel is Top`]
    let S = Math.floor(Math.random() * status.length);
    client.user.setActivity(status[S], { type: 'PLAYING' })
  };
  //ismailmgde
  setInterval(abady, 5000)

})


//// Ahmed Sn : youtube channel https://www.youtube.com/channel/UCwY0RyQCsft-vcoiQHN_S7A
const usedSpinCommands = new Map();

client.on('messageCreate', async message => {
  if (message.author.bot) return;

  if (message.content.startsWith('spin')) {
    const spinCommandUser = usedSpinCommands.get(message.author.id);
    const guildInvites = await message.guild.invites.fetch();
    const inviter = guildInvites.find(invite => invite.inviter.id === message.author.id);
    const inviteCount = inviter ? inviter.uses : 0;
const ahmed = new MessageButton()
.setCustomId('ahmed')
.setEmoji('✅')
.setLabel('الترجمة للعربى')
.setStyle('DANGER')
const moha = new MessageActionRow()
.addComponents(ahmed)
    if (spinCommandUser && spinCommandUser.inviteCount >= inviteCount) {
      await message.reply({content :'You have already used the spin command or your invite count has not increased!' , components : [moha]});
      return;
    }
    const spinButton = new Discord.MessageButton()
      .setCustomId('spin')
      .setLabel('Spin')
      .setStyle('PRIMARY')
      // .setType('BUTTON');
    
    const premiumSpinButton = new Discord.MessageButton()
      .setCustomId('premium_spin')
      .setLabel('Premium Spin')
      .setStyle('PRIMARY')
      // .setType('BUTTON');
      const cancelButton = new Discord.MessageButton()
      .setCustomId('cancel_spin')
      .setLabel('Cancel Spin')
      .setStyle('DANGER');
    
    const cancelActionRow = new Discord.MessageActionRow()
      .addComponents(cancelButton);
    const actionRow = new Discord.MessageActionRow()
      .addComponents(spinButton, premiumSpinButton);
    
    const initialMessage = await message.channel.send({ content: '**Choose your spin type: || اختار نوع اللفة على حسب انفايت حقك**', components: [actionRow , cancelActionRow] });
  
    const collector = initialMessage.createMessageComponentCollector({
      componentType: 'BUTTON',
      time: 15000, 
      max : 1
    });
    
    collector.on('collect', async interaction => {
      if (interaction.customId === 'spin') {
        if (inviteCount < 1) {
          await message.channel.send({content : `**انت يجب ان تحصل على 1 انفايت على الاقل**`})
          return;
        }

        if (inviteCount === 5 ) {
          await message.channel.send ({content : `**انت وصلت ل عدد انفايت 5 لذلك تستطيع استخدام زر البريميوم وليس العادى**`})
        }
        if (inviteCount >= 1 && inviteCount <= 4) {
          const confirmationMessage = await message.channel.send('**بالتاكيد انت تحصل على 1 انفايت جديد لذلك جارى لف العجلة**');
          usedSpinCommands.set(message.author.id, {inviteCount: inviteCount});
       
          setTimeout(async () => {
            await confirmationMessage.delete();
            const prizes = ['sdfv', 'vsvs'];
            const prize = prizes[Math.floor(Math.random() * prizes.length)];
            message.channel.send(`**تهانينا لقد فزت ب  🥳:  ${prize}!**`);
            const newInviter = await message.guild.invites.resolve(message.author.id);
            const newInviteCount = newInviter ? newInviter.uses : 0;
            if (newInviteCount > inviteCount) {
              usedSpinCommands.delete(message.author.id);
            }
          }, 5000); // Wait 5 seconds before sending the prize message
        } else {
          await interaction.reply({ content: 'You need at least 1 invite to use this command.', ephemeral: true });
        }
      } else if (interaction.customId === 'premium_spin') {
        if (inviteCount < 5) {
          await message.channel.send({content : `**انت يجب ان تحصل على الاقل 5 انفايت**`})
          return;
        }
        if(inviteCount === 10 ) {
          await message.channel.send({content : `**انت قد وصلت للحد الاقصى من عدد الانفايت**`})
        }
        if (inviteCount >= 5 && inviteCount <=10) {
          const confirmationMessage = await message.channel.send('**بالفعل انت تمتلك 4 انفايت لذلك جارى لف العجلة**.');
          usedSpinCommands.set(message.author.id, {inviteCount: inviteCount});
       
          setTimeout(async () => {
            await confirmationMessage.delete();
            const prizes = ['asdf', 'ertb', 'jklz'];
            const prize = prizes[Math.floor(Math.random() * prizes.length)];
            message.channel.send(`**تهانينا 🥳 انت فزت ب** ${prize}!`);
            const newInviter = await message.guild.invites.resolve(message.author.id);
            const newInviteCount = newInviter ? newInviter.uses : 0;
            if (newInviteCount > inviteCount) {
              usedSpinCommands.delete(message.author.id);
            }
          }, 5000); // Wait 5 seconds before sending the prize message
        } else {
          await interaction.reply({ content: 'You need at least 5 invites to use this command.', ephemeral: true });
        }
      } else if (interaction.customId === 'cancel_spin') {
        await interaction.update({ content: 'Spin canceled.', components: [] });
      }
      
      // Remove the button component from the action row
      const newActionRow = new Discord.MessageActionRow()
        .addComponents(spinButton, premiumSpinButton)
        .components.filter(component => component.customId !== interaction.customId);
          
      interaction.update({ components: [newActionRow] }); // Use 'BUTTON' instead of 'BUTTONS'
    });
    
    collector.on('end', async () => {
      const disabledSpinButton = new Discord.MessageButton()
        .setCustomId('spin')
        .setLabel('Spin')
        .setStyle('SECONDARY')
        .setDisabled(true)
        // .setType('BUTTON'); // Use 'BUTTON' instead of 'BUTTONS'
        
      const disabledPremiumSpinButton = new Discord.MessageButton()
        .setCustomId('premium_spin')
        .setLabel('Premium Spin')
        .setStyle('SECONDARY')
        .setDisabled(true)
        // .setType('BUTTON'); // Use 'BUTTON' instead of 'BUTTONS'
        
      const disabledActionRow = new Discord.MessageActionRow()
        .addComponents(disabledSpinButton, disabledPremiumSpinButton);
        
      await initialMessage.edit({ content: '....', components: [] });
    });
  }
});
////translate 


client.on('interactionCreate', async interaction => {
  if(!interaction.isButton())return
  if (interaction.customId === `ahmed`) {
    await interaction.deferReply({fetchReply :true , ephemeral :true})
    await interaction.editReply({content : `**للاسف انت قد استخدمت هذا الامر من قبل او انك لم تحضر انفايت جديدة **`})
  }
})




///// how many invites 

client.on('messageCreate', async message => {
  if (message.content.startsWith('invites')) {
    const guildInvites = await message.guild.invites.fetch();
    const userInvites = guildInvites.filter(invite => invite.inviter.id === message.author.id);

    if (userInvites.size === 0) {
      await message.reply('You have not invited anyone to the server yet.');
      return;
    }

    const inviteInfo = userInvites.map(invite => `Code: ${invite.code}, Uses: ${invite.uses}`).join('\n');
    await message.reply(`Your invites:\n${inviteInfo}`);
  }
});


/// reset all invites 

client.on('messageCreate', async message => {
  if (message.content.startsWith('reset') && message.member.permissions.has('ADMINISTRATOR')) {
    const guildInvites = await message.guild.invites.fetch();
    const inviteCodes = guildInvites.map(invite => invite.code);

    inviteCodes.forEach(async code => {
      const invite = await message.guild.invites.delete(code);
    });

    await message.reply('All invites have been reset.');
  }
});
client.login("توكن بوتك هنا");