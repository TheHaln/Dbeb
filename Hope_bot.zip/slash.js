const i18n = require('i18n');
module.exports = async (client) => {
  let array = [
    
   {
      name: "create-menu",
      description: "create menu",

    },
    {
      name: "add-menu",
      description: "make a menu",
      options: [

            {
              name: "label",
              description: ".",
              type: "STRING" ,
              required : true
            } ,
            {
              name: "description",
              description: ".",
              type: "STRING" ,
              required : true
            },
            {
              name: "value",
              description: ".",
              type: "STRING" ,
              required : true
            },


          ]
        },
        {
          name: "menu",
          description: `${i18n.__('menu')}`,
    
        },
                  
]
  await client.application.commands.set(array);
}