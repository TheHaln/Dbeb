require("dotenv").config();
const config = require("./config.json");
const prefix = config.prefix;
const Discord = require("discord.js");
const fs = require('fs');
const { MessageAttachment } = require('discord.js');
const { MessageEmbed , permissionOverwrites , ChannelType , MessageButton, MessageActionRow ,  Permissions} = require("discord.js");
const { Client, Intents } = require('discord.js');
const client = new Discord.Client({
  intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS"]
});


const setSlash = require("./slash");
const axios = require("axios");




client.on("ready", async () => {
  console.log(client.user.tag);
  await setSlash(client);
});






client.on('ready', () => {
  function abady() {
    let status = [`Ahmed Sn`]
    let S = Math.floor(Math.random() * status.length);
    client.user.setActivity(status[S], { type: 'PLAYING' })
  };
  //ismailmgde
  setInterval(abady, 5000)

})




///
client.on('messageCreate' , async message => {
  if(message.content.startsWith('نداء')) {
    if (message.author.bot) return
    if (!config.devs.find(i => i === message.author.id)) return message.reply({ content: `❌ - **انت لاتستطيع استخدام هذا الامر لانك مش ادمن يا عم.**` });


const member = message.mentions.members.first()
const channel = message.channel;
    message.reply({content : `** تم نداء ${member} للتوجه لروم  ${channel}  ✅ بنجاح  **` })
    member.send({content : ` ${member} \n **تم استدعائك هنا ${channel}**`})
  }

})

client.login("توكن هنا");